﻿namespace Library2
{


    partial class Database
    {
    }
}

namespace Library2.DatabaseTableAdapters {
    
    
    public partial class PublisherTableAdapter {
    }
}
